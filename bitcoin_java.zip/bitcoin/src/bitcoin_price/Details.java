/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bitcoin_price;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Details 
{
    static String path="";
    static String inName="";
    static int VECTOR_SIZE = 5;
    static List<Coindata> CoinDataList = new ArrayList<>();
    int sYear=2014;
    int eYear=2019;
    String year[]={"2014","2015","2016","2017","2018","2019"};
    static double closeAvg[];
            
}
